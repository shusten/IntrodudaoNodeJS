var clc = require("cli-color");

console.log(clc.green("Mensagem verde;"));

console.log(clc.red.bgWhite.underline("Underlined red text on white background."));