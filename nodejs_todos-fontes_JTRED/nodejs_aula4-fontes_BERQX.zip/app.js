var funcoes = require("./funcoes.js");

var resultado = funcoes.validarUsuario("joel", "123");

console.log(resultado);