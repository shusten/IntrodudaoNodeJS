var nome = "Joel";

function exibirMensagem(nome){
    console.log("Olá,", nome);
}

exibirMensagem(nome);